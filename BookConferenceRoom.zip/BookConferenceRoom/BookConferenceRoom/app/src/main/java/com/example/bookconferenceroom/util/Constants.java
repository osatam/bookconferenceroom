package com.example.bookconferenceroom.util;

public class Constants {

    public static final String TITLE_EMPTY = "Please fill the Title";
    public static final String DURATION_EMPTY = "Please fill the Duration";
    public static final String START_TIME = "Please fill the Start Time";
    public static final String CONFERENCE_ROOM_NOT_SELECTED = "Please Select a Conference Room";
    public static final String START_TIME_TEXT="Start Time: ";
    public static final String DURATION_TEXT="Duration(In Minutes): ";
    public static final String END_TIME_TEXT = "End Time: ";
    public static final String INVALID_START_TIME = "Conference room can be used only between 9:00a.m. to 12:00p.m. & 01:00pm to 05:00pm";
    public static final String INVALID_DURATION= "Conference room can be used only between 9:00a.m. to 12:00p.m. & 01:00pm to 05:00pm; Specify Duration Correctly";
    public static final String CONFIRM_SESSION_MESSAGE = "Are you sure to set this session?";
    public static final String CONFIRM_REJECT_SESSION_MESSAGE = "Are you sure you want to reject the session?";
    public static final String ROOM_BOOKED_SUCCESS = "Room booked successfully";
    public static final String ROOM_ALREADY_BOOKED = "Room is already booked, Please retry using different Conference Room or Start Time";
    public static final String SESSION_REJECT_SUCCESS = "Session Rejected successfully";
    public static final String SESSION_NOT_REJECTED = "Don't Worry, Your session has not been rejected, Just visit this screen again or simply rotate your device";



}
