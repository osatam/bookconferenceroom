package com.example.bookconferenceroom.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.bookconferenceroom.dao.ConferenceRoomSessionDAO;
import com.example.bookconferenceroom.entity.ConferenceRoomSession;

@Database(entities = {ConferenceRoomSession.class}, version = 2)
public abstract class SessionDatabase extends RoomDatabase {

    private static SessionDatabase instance;

    public abstract ConferenceRoomSessionDAO conferenceRoomSessionDAO();

    public static synchronized SessionDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    SessionDatabase.class, "session_database")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;
    }

}
