package com.example.bookconferenceroom.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookconferenceroom.R;
import com.example.bookconferenceroom.entity.ConferenceRoomSession;
import com.example.bookconferenceroom.util.Constants;

import java.util.ArrayList;
import java.util.List;

public class SessionAdapter extends RecyclerView.Adapter<SessionAdapter.SessionHolder> {
    private List<ConferenceRoomSession> allSessions = new ArrayList<>();

    @NonNull
    @Override
    public SessionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.session_item, parent, false);
        return new SessionHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SessionHolder holder, int position) {

        ConferenceRoomSession currentSessionItem = allSessions.get(position);
        holder.textViewConferenceRoomName.setText(currentSessionItem.getConferenceRoomName());
        holder.textViewTitle.setText(currentSessionItem.getTitle());
        holder.textViewStartTime.setText(Constants.START_TIME_TEXT +currentSessionItem.getStartTime());
        holder.textViewDuration.setText(Constants.DURATION_TEXT+currentSessionItem.getDuration());
        holder.textViewEndTime.setText(Constants.END_TIME_TEXT+currentSessionItem.getEndTime());

    }

    @Override
    public int getItemCount() {
        return allSessions.size();
    }

    public void setAllSessions(List<ConferenceRoomSession> conferenceRoomSessions) {
        this.allSessions = conferenceRoomSessions;
        notifyDataSetChanged();
    }

    public ConferenceRoomSession getSessionAt(int position){
        return allSessions.get(position);
    }

    class SessionHolder extends RecyclerView.ViewHolder {
        private TextView textViewConferenceRoomName;
        private TextView textViewTitle;
        private TextView textViewStartTime;
        private TextView textViewDuration;
        private TextView textViewEndTime;


        public SessionHolder(@NonNull View itemView) {
            super(itemView);

            textViewConferenceRoomName = itemView.findViewById(R.id.textViewConferenceRoom);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewStartTime = itemView.findViewById(R.id.textViewStartTime);
            textViewDuration = itemView.findViewById(R.id.textViewDuration);
            textViewEndTime = itemView.findViewById(R.id.textViewEndTime);


        }
    }
}
