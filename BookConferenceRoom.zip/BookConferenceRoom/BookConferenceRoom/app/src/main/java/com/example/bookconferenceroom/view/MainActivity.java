package com.example.bookconferenceroom.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.bookconferenceroom.R;
import com.example.bookconferenceroom.entity.ConferenceRoomSession;
import com.example.bookconferenceroom.util.Constants;
import com.example.bookconferenceroom.viewmodel.SessionViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Button bookConferenceRoom;
    private EditText title, duration;
    private TextView textViewAllSessions;
    private EditText startTime;
    private TimePickerDialog timePickerDialog;
    private Calendar calendar;
    private int currentHour;
    private int currentMinute;
    private String amPm;
    private ArrayAdapter<CharSequence> conferenceRoomAdapter;

    private Spinner conferenceRoomsSpinner;
    private String startTimeText, titleText, durationText;

    private SessionViewModel sessionViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        title = findViewById(R.id.editTextTitle);
        duration = findViewById(R.id.editTextDuration);
        bookConferenceRoom = findViewById(R.id.bookRoom);
        startTime = findViewById(R.id.editTextStartTime);
        textViewAllSessions = findViewById(R.id.seeAllBookedSessions);

        textViewAllSessions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent startAllSessionsActivity = new Intent(MainActivity.this,SessionDetails.class);
                startActivity(startAllSessionsActivity);

            }
        });

        sessionViewModel = ViewModelProviders.of(this).get(SessionViewModel.class);

        sessionViewModel.getAllKrishnaSessions().observe(this, new Observer<List<ConferenceRoomSession>>() {
            @Override
            public void onChanged(List<ConferenceRoomSession> sessionKrishnas) {
                //Update RecyclerView
                //Toast.makeText(MainActivity.this, "onChanged!", Toast.LENGTH_SHORT).show();
            }
        });


        /** For Conference Room Dropdown */
        conferenceRoomsSpinner = findViewById(R.id.roomOption);
        conferenceRoomAdapter = ArrayAdapter.createFromResource(this, R.array.conferenceRooms, android.R.layout.simple_spinner_item);
        conferenceRoomAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        conferenceRoomsSpinner.setAdapter(conferenceRoomAdapter);
        conferenceRoomsSpinner.setOnItemSelectedListener(this);

        /** For Start Time validation*/
        startTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar = Calendar.getInstance();
                currentHour = calendar.get(Calendar.HOUR_OF_DAY);
                currentMinute = calendar.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if (hourOfDay >= 12) {
                            amPm = "PM";
                        } else {
                            amPm = "AM";
                        }

                        /**Start Time Validation for 9:00am to 12:00pm & 01:00pm to 05:00pm*/
                        if (timePicker.getHour() < 9) {
                            Toast.makeText(MainActivity.this, Constants.INVALID_START_TIME, Toast.LENGTH_LONG).show();
                        } else if (timePicker.getHour() >= 12 && timePicker.getHour() < 13) {
                            Toast.makeText(MainActivity.this, Constants.INVALID_START_TIME, Toast.LENGTH_LONG).show();
                        } else if (timePicker.getHour() >= 17) {
                            Toast.makeText(MainActivity.this, Constants.INVALID_START_TIME, Toast.LENGTH_LONG).show();
                        } else {
                            startTime.setText(String.format("%02d:%02d", hourOfDay, minutes) + amPm);
                        }

                    }
                }, currentHour, currentMinute, false);

                timePickerDialog.show();
            }
        });

        bookConferenceRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] stringArray = getResources().getStringArray(R.array.conferenceRooms);
                if (conferenceRoomsSpinner.getSelectedItem().toString().equalsIgnoreCase(stringArray[0])) {
                    Toast.makeText(MainActivity.this, Constants.CONFERENCE_ROOM_NOT_SELECTED, Toast.LENGTH_SHORT).show();
                }

                titleText = title.getText().toString();
                if (titleText.isEmpty()) {
                    title.setError(Constants.TITLE_EMPTY);
                }

                startTimeText = startTime.getText().toString();
                if (startTimeText.isEmpty()) {
                    Toast.makeText(MainActivity.this, Constants.START_TIME, Toast.LENGTH_SHORT).show();
                }


                durationText = duration.getText().toString();
                if (durationText.isEmpty()) {
                    duration.setError(Constants.DURATION_EMPTY);
                } else {
                    validateEndTime();
                }
            }
        });


    }

    private void validateEndTime() {

        /** Logic for calculating end time considering duration(in minutes) as input */
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
        try {
            Date date = dateFormat.parse(String.format(startTime.getText().toString()));
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            int durationInInt = Integer.parseInt(durationText);
            calendar.add(Calendar.MINUTE, durationInInt);

            final String endTime = dateFormat.format(calendar.getTime());


            int endTimeInHour = calendar.get(Calendar.HOUR_OF_DAY);
            if (endTimeInHour >= 12) {
                amPm = "PM";
            } else {
                amPm = "AM";
            }
            final String endTimeAmPm = endTime.concat(amPm);

            Log.d("End Time", "End Time: " + endTime + amPm);
            Log.d("End Time In Hour", "End Time In Hour: " + endTimeInHour);

            if (endTimeInHour < 9) {
                Toast.makeText(MainActivity.this, Constants.INVALID_DURATION, Toast.LENGTH_SHORT).show();
            } else if (endTimeInHour > 12 && endTimeInHour < 13) {
                Toast.makeText(MainActivity.this, Constants.INVALID_DURATION, Toast.LENGTH_SHORT).show();

            } else if (endTimeInHour >= 17) {
                Toast.makeText(MainActivity.this, Constants.INVALID_DURATION, Toast.LENGTH_SHORT).show();
            } else {
                final String conferenceRoomName = conferenceRoomsSpinner.getSelectedItem().toString();

                /** Dialog to be displayed to confirm the details before booking the room*/
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(R.string.confirmSessionAlert)
                        .setMessage(Constants.CONFIRM_SESSION_MESSAGE +"Conference Room Name: "+conferenceRoomName+"\n"+"Title: " + titleText + "\n" + "Start Time: " + startTimeText + "\n" + "End Time: " + endTimeAmPm)
                        .setCancelable(false)
                        .setIcon(R.drawable.ic_dialog_alert)
                        .setPositiveButton(R.string.Yes, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                    if(conferenceRoomName.equals("Krishna")||conferenceRoomName.equals("Epitome")){

                                        List<ConferenceRoomSession> conferenceRoomSessions = sessionViewModel.getAlreadyBookedConferenceRoomSessions(conferenceRoomName,startTimeText,endTimeAmPm);

                                        if (conferenceRoomSessions.size()>=1){
                                            Toast.makeText(MainActivity.this, Constants.ROOM_ALREADY_BOOKED, Toast.LENGTH_LONG).show();
                                        }
                                        else{
                                            ConferenceRoomSession bookSessionDetails = new ConferenceRoomSession(conferenceRoomName,titleText,startTimeText,durationText,endTimeAmPm);
                                            sessionViewModel.insertKrishnaSession(bookSessionDetails);
                                            Log.d("Session ADD", "onClick: Added successfully"+titleText+startTimeText+durationText+endTimeAmPm);
                                            Toast.makeText(MainActivity.this, Constants.ROOM_BOOKED_SUCCESS, Toast.LENGTH_SHORT).show();
                                        }


                                    }
                                    else {
                                        Toast.makeText(MainActivity.this, "Something went wrong; Please check that you have fill the fields correctly", Toast.LENGTH_SHORT).show();
                                    }
                            }
                        }).setNegativeButton(R.string.No, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).create().show();
            }


        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {


    }
}



