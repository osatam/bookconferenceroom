package com.example.bookconferenceroom.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.bookconferenceroom.dao.ConferenceRoomSessionDAO;
import com.example.bookconferenceroom.database.SessionDatabase;
import com.example.bookconferenceroom.entity.ConferenceRoomSession;

import java.util.ArrayList;
import java.util.List;

public class SessionRepository {

    private ConferenceRoomSessionDAO conferenceRoomSessionDAO;

    private LiveData<List<ConferenceRoomSession>> allConferenceRoomSessions;

    public SessionRepository(Application application) {
        SessionDatabase database = SessionDatabase.getInstance(application);
        conferenceRoomSessionDAO = database.conferenceRoomSessionDAO();
        allConferenceRoomSessions = conferenceRoomSessionDAO.getAllConferenceRoomSessionDetails();

    }

    public void insertSessionDetails(ConferenceRoomSession sessionKrishna) {
        new InsertSessionAsyncTask(conferenceRoomSessionDAO).execute(sessionKrishna);

    }

    public void deleteSessionDetails(ConferenceRoomSession sessionKrishna) {
        new DeleteSessionAsyncTask(conferenceRoomSessionDAO).execute(sessionKrishna);

    }

    public List<ConferenceRoomSession> getAllBookedConferenceRoomSessions(String conferenceRoomName, String startTime, String endTimeAmPm) {
        List<ConferenceRoomSession> conferenceRoomSessionList;
        conferenceRoomSessionList = conferenceRoomSessionDAO.getAlreadyBookedConferenceRoomSessions(conferenceRoomName, startTime, endTimeAmPm);
        return conferenceRoomSessionList;
    }


    public void getAllKrishnaSessionDetails() {
        new GetAllKrishnaSessionAsyncTask(conferenceRoomSessionDAO).execute();
    }


    public LiveData<List<ConferenceRoomSession>> getAllKrishnaSessions() {
        return allConferenceRoomSessions;
    }


    private static class InsertSessionAsyncTask extends AsyncTask<ConferenceRoomSession, Void, Void> {

        private ConferenceRoomSessionDAO sessionKrishnaDAO;

        private InsertSessionAsyncTask(ConferenceRoomSessionDAO sessionKrishnaDAO) {
            this.sessionKrishnaDAO = sessionKrishnaDAO;
        }

        @Override
        protected Void doInBackground(ConferenceRoomSession... sessionKrishnas) {
            sessionKrishnaDAO.insertSessionDetails(sessionKrishnas[0]);
            return null;
        }
    }


    private static class DeleteSessionAsyncTask extends AsyncTask<ConferenceRoomSession, Void, Void> {

        private ConferenceRoomSessionDAO sessionKrishnaDAO;

        private DeleteSessionAsyncTask(ConferenceRoomSessionDAO sessionKrishnaDAO) {
            this.sessionKrishnaDAO = sessionKrishnaDAO;
        }

        @Override
        protected Void doInBackground(ConferenceRoomSession... sessionKrishnas) {
            sessionKrishnaDAO.deleteSessionDetails(sessionKrishnas[0]);
            return null;
        }
    }


    private static class GetAllKrishnaSessionAsyncTask extends AsyncTask<Void, Void, Void> {

        private ConferenceRoomSessionDAO sessionKrishnaDAO;

        private GetAllKrishnaSessionAsyncTask(ConferenceRoomSessionDAO sessionKrishnaDAO) {
            this.sessionKrishnaDAO = sessionKrishnaDAO;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            sessionKrishnaDAO.getAllConferenceRoomSessionDetails();
            return null;
        }
    }

    /*private class GetAllAlreadyBookedConferenceRoomSessions extends AsyncTask<Void, Void, List<ConferenceRoomSession>> {

        private ConferenceRoomSessionDAO sessionKrishnaDAO;
        private List<ConferenceRoomSession> conferenceRoomSessionList;

        private String conferenceRoomName,startTime,endTimeAmPm;

        public GetAllAlreadyBookedConferenceRoomSessions(ConferenceRoomSessionDAO conferenceRoomSessionDAO, String conferenceRoomName, String startTime, String endTimeAmPm) {
            this.sessionKrishnaDAO=conferenceRoomSessionDAO;
            this.conferenceRoomName = conferenceRoomName;
            this.startTime=startTime;
            this.endTimeAmPm=endTimeAmPm;
        }

        @Override
        protected List<ConferenceRoomSession> doInBackground(Void... voids) {
            conferenceRoomSessionList = sessionKrishnaDAO.getAlreadyBookedConferenceRoomSessions(conferenceRoomName,startTime,endTimeAmPm);
            return conferenceRoomSessionList;
        }
    }*/


}
