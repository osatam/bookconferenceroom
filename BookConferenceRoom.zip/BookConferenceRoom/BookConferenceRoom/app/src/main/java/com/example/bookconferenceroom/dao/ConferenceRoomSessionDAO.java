package com.example.bookconferenceroom.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.bookconferenceroom.entity.ConferenceRoomSession;

import java.util.List;

@Dao
public interface ConferenceRoomSessionDAO {

    @Insert
    void insertSessionDetails(ConferenceRoomSession bookConferenceRoomSessionDetails);

    @Delete
    void deleteSessionDetails(ConferenceRoomSession rejectConferenceRoomSessionDetails);

    @Query("SELECT * FROM SESSION_CONFERENCE_ROOM_TABLE ORDER BY id  DESC")
    LiveData<List<ConferenceRoomSession>> getAllConferenceRoomSessionDetails();

    @Query("SELECT * FROM SESSION_CONFERENCE_ROOM_TABLE WHERE conferenceRoomName = :conferenceRoomName and startTime = :startTime  and endTime= :endTime")
    List<ConferenceRoomSession> getAlreadyBookedConferenceRoomSessions(String conferenceRoomName, String startTime, String endTime);
}
