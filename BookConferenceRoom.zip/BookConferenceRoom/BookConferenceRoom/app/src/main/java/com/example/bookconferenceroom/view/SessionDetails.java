package com.example.bookconferenceroom.view;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.bookconferenceroom.R;
import com.example.bookconferenceroom.adapter.SessionAdapter;
import com.example.bookconferenceroom.entity.ConferenceRoomSession;
import com.example.bookconferenceroom.util.Constants;
import com.example.bookconferenceroom.viewmodel.SessionViewModel;

import java.util.ArrayList;
import java.util.List;

public class SessionDetails extends AppCompatActivity {
    private SessionViewModel sessionViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_session_details);

        final RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final SessionAdapter sessionAdapter = new SessionAdapter();
        recyclerView.setAdapter(sessionAdapter);

        sessionViewModel = ViewModelProviders.of(this).get(SessionViewModel.class);

        sessionViewModel.getAllKrishnaSessions().observe(this, new Observer<List<ConferenceRoomSession>>() {
            @Override
            public void onChanged(List<ConferenceRoomSession> conferenceRoomSessionsList) {
                //Update RecyclerView
                sessionAdapter.setAllSessions(conferenceRoomSessionsList);
            }
        });

        /** To enable from swipe to right or left to reject the session */

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull final RecyclerView.ViewHolder viewHolder, int direction) {

                AlertDialog.Builder builder = new AlertDialog.Builder(SessionDetails.this);
                builder.setTitle(R.string.confirmRejectSessionAlert)
                        .setMessage(Constants.CONFIRM_REJECT_SESSION_MESSAGE)
                        .setCancelable(false)
                        .setIcon(R.drawable.ic_dialog_alert)
                        .setPositiveButton(R.string.Yes, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                sessionViewModel.deleteSession(sessionAdapter.getSessionAt(viewHolder.getAdapterPosition()));
                                Toast.makeText(SessionDetails.this, Constants.SESSION_REJECT_SUCCESS, Toast.LENGTH_SHORT).show();
                            }
                        }).setNegativeButton(R.string.No, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SessionDetails.this, Constants.SESSION_NOT_REJECTED, Toast.LENGTH_SHORT).show();
                        dialogInterface.dismiss();
                    }
                }).create().show();

            }
        }).attachToRecyclerView(recyclerView);
    }
}