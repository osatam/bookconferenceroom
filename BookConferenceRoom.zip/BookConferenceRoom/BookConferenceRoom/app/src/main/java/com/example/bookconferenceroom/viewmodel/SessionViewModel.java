package com.example.bookconferenceroom.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.bookconferenceroom.adapter.SessionAdapter;
import com.example.bookconferenceroom.entity.ConferenceRoomSession;
import com.example.bookconferenceroom.repository.SessionRepository;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SessionViewModel extends AndroidViewModel {
    private SessionRepository repository;
    private LiveData<List<ConferenceRoomSession>> allSessions;
    List<ConferenceRoomSession> conferenceRoomSessions = new ArrayList<>();

    public SessionViewModel(@NonNull Application application) {
        super(application);
        repository = new SessionRepository(application);
        allSessions = repository.getAllKrishnaSessions();

    }

    public void insertKrishnaSession(ConferenceRoomSession sessionDetails) {
        repository.insertSessionDetails(sessionDetails);
    }

    public void deleteSession(ConferenceRoomSession sessionDetails) {
        repository.deleteSessionDetails(sessionDetails);
    }


    public LiveData<List<ConferenceRoomSession>> getAllKrishnaSessions() {
        return allSessions;
    }

    public List<ConferenceRoomSession> getAlreadyBookedConferenceRoomSessions(String conferenceName, String startTime, String endTimeAmPm) {
        conferenceRoomSessions = repository.getAllBookedConferenceRoomSessions(conferenceName, startTime, endTimeAmPm);
        return conferenceRoomSessions;
    }
}
