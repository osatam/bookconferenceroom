package com.example.bookconferenceroom.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "session_conference_room_table")
public class ConferenceRoomSession {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String  conferenceRoomName;

    private String title;

    private String startTime;

    private String duration;

    private String endTime;

    public ConferenceRoomSession(String conferenceRoomName,String title, String startTime, String duration, String endTime) {
        this.conferenceRoomName = conferenceRoomName;
        this.title = title;
        this.startTime = startTime;
        this.duration = duration;
        this.endTime = endTime;
    }

    public void setId(int id) {
        this.id = id;
    }

    //In order to persist the data into the database; creating the getter methods for the above fields
    public int getId() {
        return id;
    }

    public String getConferenceRoomName(){return conferenceRoomName;}

    public String getTitle() {
        return title;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getDuration() {
        return duration;
    }

    public String getEndTime() {
        return endTime;
    }
}
